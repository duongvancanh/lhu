<div class="domain">
    <div class="container">
        <form class="search-form domain-search">
            <div class="two-fifth column first">
                <img src="images/search.png" alt=""/>
                <h2><span class="m_1">Kiểm Tra</span><br>Tên Miền</h2>
            </div>
            <div class="three-fifth column first">
                <input type="text" class="text" value="Nhập Tên Miền " onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'Enter your domain name';}">
            </div>
            <div class="one-fifth column">
                                    	<span class="selection-box"><select class="domains valid" name="domains">
                                                <option>Year(0-1 Year)</option>
                                                <option>.info (From $3 / Year)</option>
                                                <option>.net (From $3 / Year)</option>
                                                <option>.org (From $3 / Year)</option>
                                            </select></span>
            </div>
            <div class="one-fifth column">
                                    	<span class="selection-box"><select class="domains valid" name="domains">
                                                <option>.com</option>
                                                <option>.info (From $3 / Year)</option>
                                                <option>.net (From $3 / Year)</option>
                                                <option>.org (From $3 / Year)</option>
                                            </select></span>
            </div>
            <div class="one-fifth column">
                <input type="submit" value="Tìm Kiếm">
            </div>
            <div class="clearfix"> </div>
        </form>
    </div>
</div>
<div class="benefit">
    <div class="container">
        <h4 class="tz-title-4 tzcolor-blue">
            <p class="tzweight_Bold"><span class="m_1">our<br></span>Benefits</p>
        </h4>
        <div class="box1">
            <div class="col-md-4 row_10">
                <ul class="service_grid">
                    <i class="s1"> </i>
                    <li class="desc">
                        <h3>99.9% Uptime</h3>
                        <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been.</p>
                    </li>
                    <div class="clearfix"> </div>
                </ul>
            </div>
            <div class="col-md-4">
                <ul class="service_grid">
                    <i class="s2"> </i>
                    <li class="desc">
                        <h3>24/7/365 Support</h3>
                        <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been.</p>
                    </li>
                    <div class="clearfix"> </div>
                </ul>
            </div>
            <div class="col-md-4">
                <ul class="service_grid">
                    <i class="s3"> </i>
                    <li class="desc">
                        <h3>Protect Your pc</h3>
                        <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been.</p>
                    </li>
                    <div class="clearfix"> </div>
                </ul>
            </div>
        </div>
        <div class="box1">
            <div class="col-md-4">
                <ul class="service_grid">
                    <i class="s4"> </i>
                    <li class="desc">
                        <h3>DNS Control</h3>
                        <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been.</p>
                    </li>
                    <div class="clearfix"> </div>
                </ul>
            </div>
            <div class="col-md-4">
                <ul class="service_grid">
                    <i class="s5"> </i>
                    <li class="desc">
                        <h3>Domain Transfer</h3>
                        <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been.</p>
                    </li>
                    <div class="clearfix"> </div>
                </ul>
            </div>
            <div class="col-md-4">
                <ul class="service_grid">
                    <i class="s6"> </i>
                    <li class="desc">
                        <h3>100% Security</h3>
                        <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been.</p>
                    </li>
                    <div class="clearfix"> </div>
                </ul>
            </div>
        </div>
    </div>
</div>
<div class="features">
    <div class="container">
        <div class="col-md-4">
            <h4 class="tz-title-4 tzcolor-blue">
                <p class="tzweight_Bold m_2"><span class="m_1">Now<br></span>What is Hot</p>
            </h4>
            <ul class="offer">
                <li><p class="m_3"><span class="m_4">Get Up to<br></span>50%</p></li>
                <li><p class="m_5">Off</p></li>
                <li class="last"><p class="m_6"><span class="m_7">Each<br></span>Hosting</p></li>
            </ul>
        </div>
        <div class="col-md-8 row_1">
            <h4 class="tz-title-4 tzcolor-blue">
                <p class="tzweight_Bold m_2"><span class="m_1">Our<br></span>Features</p>
            </h4>
            <div class="section_1">
                <div class="col_1_of_3 span_1_of_3">
                    <div class="list_1">
                        <ul>
                            <li><a href="">Lorem ipsum is simply.</a></li>
                            <li><a href="">It is a long established.</a></li>
                            <li><a href="">The standard chunk.</a></li>
                            <li><a href="">Therefore always free</a></li>
                        </ul>
                    </div>
                </div>
                <div class="col_1_of_3 span_1_of_3">
                    <div class="list_1">
                        <ul>
                            <li><a href="">Voluptatem accusan.</a></li>
                            <li><a href="">Ipsum generatortss.</a></li>
                            <li><a href="">Lorem ipsum is simply.</a></li>
                            <li><a href="">It is a long established.</a></li>
                        </ul>
                    </div>
                </div>
                <div class="col_1_of_3 span_1_of_3">
                    <a class="but1" href="#">View All</a>
                </div>
                <div class="clearfix"> </div>
            </div>
        </div>
    </div>
</div>
<div class="price">
    <div class="container">
        <h4 class="tz-title-4 tzcolor-blue">
            <p class="tzweight_Bold"><span class="m_1">our<br></span>Benefits</p>
        </h4>
        <div class="col-md-3">
            <div class="pricing-table-grid">
                <h3><span class="dollar">$</span>5<br><span class="month">Per Month</span></h3>
                <ul>
                    <li><span>Standard Plan</span></li>
                    <li><a href="#">10GB Disk Space</a></li>
                    <li><a href="#">1TB Bandwidth</a></li>
                    <li><a href="#">Free DDoS Protection</a></li>
                    <li><a href="#">Free Daily Backups</a></li>
                    <li><a href="#">Managed Hosting</a></li>
                </ul>
                <a class="popup-with-zoom-anim order-btn" href="#small-dialog">Sign Up</a>
            </div>
            <div id="small-dialog" class="mfp-hide">
                <div class="pop_up">
                    <div class="payment-online-form-left">
                        <form>
                            <h4><span class="shipping"> </span>Shipping</h4>
                            <ul>
                                <li><input class="text-box-dark" type="text" value="Frist Name" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'Frist Name';}"></li>
                                <li><input class="text-box-dark" type="text" value="Last Name" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'Last Name';}"></li>
                            </ul>
                            <ul>
                                <li><input class="text-box-dark" type="text" value="Email" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'Email';}"></li>
                                <li><input class="text-box-dark" type="text" value="Company Name" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'Company Name';}"></li>
                            </ul>
                            <ul>
                                <li><input class="text-box-dark" type="text" value="Phone" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'Phone';}"></li>
                                <li><input class="text-box-dark" type="text" value="Address" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'Address';}"></li>
                                <div class="clearfix"> </div>
                            </ul>
                            <div class="clear"> </div>
                            <ul class="payment-type">
                                <h4><span class="payment"> </span> Payments</h4>
                                <li>
													<span class="col_checkbox">
													<input id="3" class="css-checkbox1" type="checkbox">
													<label for="3" name="demo_lbl_1" class="css-label1"> </label>
													<a class="visa" href="#"> </a>
													</span>
                                </li>
                                <li>
													<span class="col_checkbox">
														<input id="4" class="css-checkbox2" type="checkbox">
														<label for="4" name="demo_lbl_2" class="css-label2"> </label>
														<a class="paypal" href="#"> </a>
													</span>
                                </li>
                                <div class="clearfix"> </div>
                            </ul>
                            <ul>
                                <li><input class="text-box-dark" type="text" value="Card Number" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'Card Number';}"></li>
                                <li><input class="text-box-dark" type="text" value="Name on card" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'Name on card';}"></li>
                                <div class="clearfix"> </div>
                            </ul>
                            <ul>
                                <li><input class="text-box-light hasDatepicker" type="text" id="datepicker" value="Expiration Date" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'Expiration Date';}"><em class="pay-date"> </em></li>
                                <li><input class="text-box-dark" type="text" value="Security Code" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'Security Code';}"></li>
                                <div class="clearfix"> </div>
                            </ul>
                            <ul class="payment-sendbtns">
                                <li><input type="reset" value="Cancel"></li>
                                <li><input type="submit" value="Process order"></li>
                            </ul>
                            <div class="clearfix"> </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="pricing-table-grid">
                <h3><span class="dollar">$</span>6<br><span class="month">
Mỗi Tháng</span></h3>
                <ul>
                    <li><span>Advanced Plan</span></li>
                    <li><a href="#">10GB Disk Space</a></li>
                    <li><a href="#">1TB Bandwidth</a></li>
                    <li><a href="#">Free DDoS Protection</a></li>
                    <li><a href="#">Free Daily Backups</a></li>
                    <li><a href="#">Managed Hosting</a></li>
                </ul>
                <a class="popup-with-zoom-anim order-btn" href="#small-dialog">Đăng Ký</a>
            </div>
        </div>
        <div class="col-md-3">
            <div class="pricing-table-grid">
                <h3><span class="dollar">$</span>8<br><span class="month">
Mỗi Tháng</span></h3>
                <ul>
                    <li><span>Business Plan</span></li>
                    <li><a href="#">10GB Disk Space</a></li>
                    <li><a href="#">1TB Bandwidth</a></li>
                    <li><a href="#">Free DDoS Protection</a></li>
                    <li><a href="#">Free Daily Backups</a></li>
                    <li><a href="#">Managed Hosting</a></li>
                </ul>
                <a class="popup-with-zoom-anim order-btn" href="#small-dialog">Đăng Ký</a>
            </div>
        </div>
        <div class="col-md-3">
            <div class="pricing-table-grid">
                <h3><span class="dollar">$</span>9<br><span class="month">
Mỗi Tháng</span></h3>
                <ul>
                    <li><span>Gold Plan</span></li>
                    <li><a href="#">10GB Disk Space</a></li>
                    <li><a href="#">1TB Bandwidth</a></li>
                    <li><a href="#">Free DDoS Protection</a></li>
                    <li><a href="#">Free Daily Backups</a></li>
                    <li><a href="#">Managed Hosting</a></li>
                </ul>
                <a class="popup-with-zoom-anim order-btn" href="#small-dialog">Đăng Ký</a>
            </div>
        </div>
        <div class="clearfix"> </div>
    </div>
</div>
<div class="domain">
    <div class="container">
        <form class="search-form domain-search">
            <div class="two-fifth signup column first">
                <img src="images/msg.png" alt=""/>
                <h2><span class="m_1">Đăng Ký Nhận</span><br>Thư Mới</h2>
            </div>
            <div class="three-fifth searchbar column first">
                <input type="text" class="text" value="Tên Domain của bạn" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'Enter your domain name';}">
            </div>
            <div class="one-fifth col_2 ">
                <input type="submit" value="Đăng Ký Ngay">
            </div>
            <div class="clearfix"> </div>
        </form>
    </div>
</div>