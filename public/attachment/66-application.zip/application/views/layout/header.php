<!--
Author: W3layouts
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<!DOCTYPE HTML>
<html>
<head>
    <title>Hosting an Hosting Category Flat Bootstarp Resposive Website Template | Home :: w3layouts</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta name="keywords" content="Hosting Responsive web template, Bootstrap Web Templates, Flat Web Templates, Andriod Compatible web template,
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyErricsson, Motorola web design" />
    <script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
    <link href="<?php echo base_url()?>public/css/bootstrap.css" rel='stylesheet' type='text/css' />

    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="<?php echo base_url()?>public/js/jquery-1.11.1.min.js"></script>
    <!-- Custom Theme files -->
    <link href="<?php echo base_url()?>public/css/style.css" rel='stylesheet' type='text/css' />
    <!-- Custom Theme files -->
    <!-- webfonts -->
    <link href='http://fonts.googleapis.com/css?family=Open+Sans:100,200,300,400,500,600,700,800,900' rel='stylesheet' type='text/css'>
    <!-- webfonts -->
    <!-- Add fancyBox main JS and CSS files -->
    <script src="<?php echo base_url()?>public/js/jquery.magnific-popup.js" type="text/javascript"></script>
    <link href="<?php echo base_url()?>public/css/popup.css" rel="stylesheet" type="text/css">
    <script>
        $(document).ready(function() {
            $('.popup-with-zoom-anim').magnificPopup({
                type: 'inline',
                fixedContentPos: false,
                fixedBgPos: true,
                overflowY: 'auto',
                closeBtnInside: true,
                preloader: false,
                midClick: true,
                removalDelay: 300,
                mainClass: 'my-mfp-zoom-in'
            });
        });
    </script>
</head>
<body>
<div class="header">
    <div class="container">
        <div class="header_top">
            <div class="logo">
                <a href="index.html"><img src="<?php echo base_url()?>public/images/logo.png" style="width:220px;" alt=""/></a>
            </div>
            <div class="cssmenu">
                <ul>
                    <li><a href="mailto:info@mycompany.com">info(at)webhosting.com</a></li>
                    <li class="active"><a href="login.html">Đăng Nhập</a></li>
                    <li><a href="register.html">Đăng Ký</a></li>
                </ul>
            </div>
            <div class="clearfix"> </div>
        </div>
        <div class="h_menu4"><!-- start h_menu4 -->
            <a class="toggleMenu" href="#">Menu</a>
            <ul class="nav">
                <li class="active"><a href="index.html">Trang Chủ</a></li>
                <li><a href="about.html">Về Chúng Tôi</a></li>
                <li><a href="service.html">Dịch Vụ</a></li>
                <li><a href="plans.html">Hosting Plans</a></li>
                <li><a href="domain.html">Domain</a></li>
                <li><a href="faq.html">FAQ</a></li>
                <li><a href="testimonials.html">Testimonials</a></li>
                <li><a href="blog.html">Blog</a></li>
                <li><a href="support.html">Hỗ Trợ</a></li>
                <li><a href="contact.html">Liên Hệ</a></li>
            </ul>
            <script type="text/javascript" src="js/nav.js"></script>
        </div><!-- end h_menu4 -->
    </div>
</div>