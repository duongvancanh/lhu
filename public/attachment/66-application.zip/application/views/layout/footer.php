<div class="footer">
    <div class="container">
        <div class="col-md-3 box_1">
            <img src="images/f_logo.png" alt=""/>
            <p>© 2015 Template by <a href="http://w3layouts.com" target="_blank"> w3layouts</a></p>
        </div>
        <div class="col-md-3 box_2">
            <h4>Quick Links</h4>
            <ul class="list_2">
                <li><a href="#">Trang Chủ</a></li>
                <li><a href="#">Về Chúng Tôi</a></li>
                <li><a href="#">Service</a></li>
                <li><a href="#">Hosting Plans</a></li>
                <li><a href="#">Domains</a></li>
            </ul>
            <ul class="list_2">
                <li><a href="#">Faq</a></li>
                <li><a href="#">Blog</a></li>
                <li><a href="#">Hỗ Trợ</a></li>
                <li><a href="#">Liên Hệ</a></li>
            </ul>
            <div class="clearfix"> </div>
        </div>
        <div class="col-md-3 box_2">
            <h4>Contact Us</h4>
            <address class="address">
                <dl>
                    <dt></dt>
                    <dd>Address : <span>9/9 Huỳnh Văn Nghệ Bửu Long Biên Hòa Đồng Nai</span></dd>
                    <dd>E-mail : <a href="mailto@example.com">vnaptech@gmail.com</a></dd>
                    <dd>Call : <span> +64 09090909</span></dd>
                </dl>
            </address>
        </div>
        <div class="col-md-3 box_2">
            <h4>Social Media</h4>
            <ul class="footer_social">
                <li><a href=""> <i class="fb"> </i> </a></li>
                <li><a href=""><i class="tw"> </i> </a></li>
                <li><a href=""><i class="linkedin"> </i> </a></li>
                <li><a href=""><i class="google"> </i> </a></li>
            </ul>
        </div>
    </div>
</div>
<link href="css/flexslider.css" rel='stylesheet' type='text/css' />
<script defer src="js/jquery.flexslider.js"></script>
<script type="text/javascript">
    $(function(){
        SyntaxHighlighter.all();
    });
    $(window).load(function(){
        $('.flexslider').flexslider({
            animation: "slide",
            start: function(slider){
                $('body').removeClass('loading');
            }
        });
    });
</script>
</body>
</html>